#include <stdio.h>
#include<math.h>
int main()
{int k,i=5,j=1,n,l;
for(n=1;n<=5;n++)
{for(k=5;k>=n;k--)
{if(k==n)
{printf("%d",k);
for(l=n-1;l>0;l--)
printf("%d",l);
}
else
printf(" ");
}
printf("\n");}
   return 0;
}
