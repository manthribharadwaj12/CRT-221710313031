#include <stdio.h>
#include<math.h>

int main()
{int n=5,i=0,k=53;
printf("%d %d ",k,k);
while(k>=n)
{k=k-13;
printf("%d %d ",k,k);        
}
}
