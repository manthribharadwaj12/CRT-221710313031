#include <stdio.h>
#include<math.h>

int main()
{int n=5,i=0,k=7,next=3;
printf("7\t");
for(i=1;k<n;i++)
{if(i%2!=0)
 {k=k+3;
printf("%d\t",k);
 } 
 else
 {k=k-2;
printf("%d\t",k);
 }
}
}
