#include <stdio.h>
#include<math.h>
int main()
{
  int a,b,rate;
  scanf("%d%d",&a,&b);
  if(a>100 || b>100)
  {printf("%d runs in %d overs @ %d runs per over",a,b,a/b);}
  else
  {printf("%d runs in %d ball @ %d runs per ball",a,b,a/b);}
}