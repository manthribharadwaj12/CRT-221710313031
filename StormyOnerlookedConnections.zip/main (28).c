#include <stdio.h>
#include<math.h>
int main()
{
  int n=5;
  printf("*\n");
  for (int i=1;i<=n;i++)
  { printf("*");
      for(int j=1;j<=i;j+=1)
      { printf("%d",j);
      }
      for(int j=i-1;j>=1;j-=1)
      { printf("%d",j);}
      printf("*\n");
  }
}