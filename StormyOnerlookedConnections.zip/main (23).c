#include <stdio.h>
#include<math.h>

int main ()
{
  int n = 10, l = 80, i, k = 10;
  for (i = 1; i <= n; i++)
    {
      if (i % 2 != 0)
	{
	  printf ("%d ", l);
	  l= l - 10;
	}
      else
	{
	  printf ("%d ", k);
	  k = k + 5;
	}
    }
}
