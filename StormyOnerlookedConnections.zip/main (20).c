#include <stdio.h>
#include<math.h>

int main()
{int n=5,i=0,k=3,next=3;
printf("3+");
for(i=1;i<n;i++)
{ next=next+3*pow(10,i);
if(i!=n-1)
 printf("%d+",next);
else
printf("%d",next);
}
}
