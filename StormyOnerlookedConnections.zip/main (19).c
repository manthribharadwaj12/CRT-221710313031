#include <stdio.h>
#include<math.h>

int main()
{ int a=555,j,product=1,dum,k=0,i=0,sum=0,b;
b=a;
dum=b;
while(a!=0)
{ 
a=a/10;
i++;       
}
while(b!=0)
{
k=b%10;
printf("%d\n",k);
product=1;
product*=pow(k,i);
sum=sum+product;
printf("%d %d\n",sum,product);
b=b/10;
}
if(sum==dum)
printf("ARmStrong");
else
printf("not ARmStrong");

}
