#include <stdio.h>

int main ()
{
 int a=11,b=12,sum=b;
 while(a!=1)
 {
         a=a/2;
         if(a%2!=0)
         sum+=b*2;
         b=b*2;
 }
 printf("%d",sum);
   return 0;
}
