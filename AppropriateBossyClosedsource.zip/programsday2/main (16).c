#include <stdio.h>

int main ()
{
  int balance=1000,pin,a,b;
   scanf ("%d ",&pin);
  if(pin==1236)
 {
  printf("1b2d3w4e\n");
  scanf ("%d",&a);
  switch(a){
          case 1: printf("%d",balance);
          break;
          case 2: scanf("%d",&b);
          if(b%100==0)
          {balance+=b;
           printf("%d",balance);}
          else
          printf("u can't");
          break;
          case 3: scanf("%d",&b);
          if(b%100==0)
          {if(balance>500)
          {balance-=b;
          printf("%d",balance);
          }
          else
          printf("low balance");}
          else
          printf("u can't");
          break;
          case 4:
          break;
          default:printf("Invalid");
          break;
  }}
  else
  printf("Invalid pin");
   return 0;
}
