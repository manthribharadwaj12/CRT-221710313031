#include <stdio.h>

int main(void) {
  int a;
 scanf("%2d",&a);
 printf("%d\n",a);
 printf("%d",(a%10)-(a/10));
 return 0;
}
