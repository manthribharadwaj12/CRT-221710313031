#include <stdio.h>

int main(void) {
  char ch;
  puts("enter character");
  ch=getchar();
  putchar(ch);
  return 0;
}