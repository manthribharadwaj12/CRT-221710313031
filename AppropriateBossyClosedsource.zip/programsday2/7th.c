#include <stdio.h>

int main(void) {
  int a=10;
  printf("%d %d %d\n",a,a++,++a);
  return 0;
}