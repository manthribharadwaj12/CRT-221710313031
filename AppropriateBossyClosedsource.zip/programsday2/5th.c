#include <stdio.h>

int main(void) {
int a;
int x= printf("hi");
int y=scanf("%d",&a);
printf("%d %d",x,y);
  return 0;
}