#include <stdio.h>

int main(void) {
   printf("%d",printf("hi"));
  return 0;
}