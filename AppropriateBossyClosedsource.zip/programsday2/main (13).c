#include <stdio.h>

int main(void) {
  int a;
 scanf("%d",&a);
 if(a%5==0 && a%3==0)
 printf("FIZZBIZZ");
 else if(a%5==0)
 printf("BIZZ");
 else if(a%3==0)
 printf("FIZZ");
 else
 printf("no.");
 return 0;
}
