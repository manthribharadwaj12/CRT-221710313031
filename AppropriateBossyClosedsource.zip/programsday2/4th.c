#include <stdio.h>

int main(void) {
  char ch[10];
  puts("enter str");
  scanf("%[^\n]s",ch);
  puts(ch);
  return 0;
}