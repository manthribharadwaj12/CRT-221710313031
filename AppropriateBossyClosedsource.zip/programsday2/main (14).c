#include <stdio.h>

int main (void)
{
  int a,b,c;
  scanf ("%d %d %d",&a,&b,&c);
  if (a==b && b==c)
    printf ("=vilateral");
  else if (a==b || b==c || c==a)
    printf ("Isosceles");
  else
    printf ("scalen");
  return 0;
}
