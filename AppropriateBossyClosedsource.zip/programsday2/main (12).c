#include <stdio.h>

int main(void) {
  int a;
 scanf("%d",&a);
 if(a<150)
 printf("Dwarf");
  else
   if(a>150 && a<165)
        printf("avg h8");
    else
      if(a>165 && a<195)
       printf("tall");
    else
    printf("abnornal");
 
 return 0;
}
