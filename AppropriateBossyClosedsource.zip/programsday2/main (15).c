#include <stdio.h>

int main (void)
{
  int a,b=10,c=10;
  printf("+-*/modulo\t");
  scanf ("%d ",&a);
  switch(a){
          case 1: printf("%d",c+b);
          break;
          case 2: printf("%d",c-b);
          break;
          case 3: printf("%d",c*b);
          break;
          case 4:printf("%d",c/b);
          break;
          case 5:printf("%d",c%b);
          break;
          default:printf("%d %d",c,b);
          break;
  }
   return 0;
}
