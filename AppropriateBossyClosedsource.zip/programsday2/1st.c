#include <stdio.h>

int main(void) {
  char ch;
  puts("enter character");
  ch=getc(stdin);
  fflush(stdin);
  putc(ch, stdout);
  return 0;
}