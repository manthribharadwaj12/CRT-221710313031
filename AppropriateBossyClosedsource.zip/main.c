#include <stdio.h>

int main(void) {
  char ch[10];
  puts("enter str");
  gets(ch);
  puts(c)
  return 0;
}